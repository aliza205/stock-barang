# Stok Barang (Android)
Aplikasi pencatat stok barang masuk/keluar dengan kode unik barang dan nomor batch.
Kotlin + Jetpack Compose + Room (offline, data tersimpan di HP).

## Build via GitHub
1. Upload semua isi folder ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis saat push).
3. Setelah hijau, buka run-nya -> **Artifacts** -> unduh `stok-barang-apk` -> install `app-debug.apk`.
