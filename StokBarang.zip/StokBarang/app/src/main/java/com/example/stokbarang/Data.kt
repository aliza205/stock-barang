package com.example.stokbarang

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "items", indices = [Index(value = ["code"], unique = true)])
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val unit: String
)

@Entity(tableName = "transactions")
data class StockTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemCode: String,
    val batchNo: String,
    val type: String, // "IN" atau "OUT"
    val qty: Int,
    val time: Long,
    val note: String
)

data class BatchStock(val itemCode: String, val batchNo: String, val stock: Int)

@Dao
interface StockDao {
    @Insert
    suspend fun insertItem(item: Item): Long

    @Query("SELECT * FROM items ORDER BY name")
    fun items(): Flow<List<Item>>

    @Query("SELECT * FROM items WHERE code = :code LIMIT 1")
    suspend fun findItem(code: String): Item?

    @Insert
    suspend fun insertTx(tx: StockTx)

    @Query("SELECT * FROM transactions ORDER BY time DESC")
    fun history(): Flow<List<StockTx>>

    @Query(
        "SELECT itemCode, batchNo, " +
            "SUM(CASE WHEN type = 'IN' THEN qty ELSE -qty END) AS stock " +
            "FROM transactions GROUP BY itemCode, batchNo"
    )
    fun batchStocks(): Flow<List<BatchStock>>

    @Query(
        "SELECT COALESCE(SUM(CASE WHEN type = 'IN' THEN qty ELSE -qty END), 0) " +
            "FROM transactions WHERE itemCode = :code AND batchNo = :batch"
    )
    suspend fun stockOf(code: String, batch: String): Int
}

@Database(entities = [Item::class, StockTx::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): StockDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(context: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "stok.db")
                .build().also { inst = it }
        }
    }
}
