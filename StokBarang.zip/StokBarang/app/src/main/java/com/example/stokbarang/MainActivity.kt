package com.example.stokbarang

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDb.get(this).dao()
        setContent {
            MaterialTheme { App(dao) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(dao: StockDao) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Stok" to "📦", "Barang" to "🏷️", "Transaksi" to "🔄", "Riwayat" to "🕘")
    Scaffold(
        topBar = { TopAppBar(title = { Text("Stok Barang") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> StokScreen(dao)
                1 -> BarangScreen(dao)
                2 -> TxScreen(dao)
                else -> RiwayatScreen(dao)
            }
        }
    }
}

@Composable
fun StokScreen(dao: StockDao) {
    val itemList by remember { dao.items() }.collectAsState(emptyList())
    val stocks by remember { dao.batchStocks() }.collectAsState(emptyList())
    var q by remember { mutableStateOf("") }
    val filtered = itemList.filter { i ->
        q.isBlank() || i.name.contains(q, true) || i.code.contains(q, true) ||
            stocks.any { it.itemCode == i.code && it.batchNo.contains(q, true) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            label = { Text("Cari kode / nama / batch") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        if (filtered.isEmpty()) Text("Belum ada data. Tambahkan barang di tab Barang.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { item ->
                val bs = stocks.filter { it.itemCode == item.code }.sortedBy { it.batchNo }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kode: ${item.code}")
                        Text("Total: ${bs.sumOf { it.stock }} ${item.unit}", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        bs.forEach {
                            Row(Modifier.fillMaxWidth()) {
                                Text("Batch ${it.batchNo}", Modifier.weight(1f))
                                Text("${it.stock} ${item.unit}", color = if (it.stock == 0) Color.Gray else Color.Unspecified)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BarangScreen(dao: StockDao) {
    val scope = rememberCoroutineScope()
    val itemList by remember { dao.items() }.collectAsState(emptyList())
    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("pcs") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(code, { code = it }, label = { Text("Kode unik barang") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it }, label = { Text("Nama barang") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(unit, { unit = it }, label = { Text("Satuan (pcs, box, kg)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                val c = code.trim().uppercase()
                when {
                    c.isEmpty() || name.isBlank() -> msg = "Kode dan nama wajib diisi"
                    dao.findItem(c) != null -> msg = "Kode $c sudah dipakai"
                    else -> {
                        dao.insertItem(Item(code = c, name = name.trim(), unit = unit.trim().ifEmpty { "pcs" }))
                        msg = "Barang $c ditambahkan"
                        code = ""; name = ""
                    }
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Simpan Barang") }
        if (msg.isNotEmpty()) Text(msg, Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(itemList, key = { it.id }) {
                Text("${it.code} — ${it.name} (${it.unit})")
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun TxScreen(dao: StockDao) {
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf("IN") }
    var code by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<Item?>(null) }
    var current by remember { mutableStateOf<Int?>(null) }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(code, batch) {
        val c = code.trim().uppercase()
        val b = batch.trim().uppercase()
        found = if (c.isEmpty()) null else dao.findItem(c)
        current = if (found != null && b.isNotEmpty()) dao.stockOf(c, b) else null
    }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            if (type == "IN") Button({ type = "IN" }, Modifier.weight(1f)) { Text("Barang Masuk") }
            else OutlinedButton({ type = "IN" }, Modifier.weight(1f)) { Text("Barang Masuk") }
            if (type == "OUT") Button({ type = "OUT" }, Modifier.weight(1f)) { Text("Barang Keluar") }
            else OutlinedButton({ type = "OUT" }, Modifier.weight(1f)) { Text("Barang Keluar") }
        }
        OutlinedTextField(code, { code = it }, label = { Text("Kode unik barang") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text(
            found?.let { "✔ ${it.name} (${it.unit})" } ?: if (code.isBlank()) "" else "Kode tidak ditemukan",
            color = if (found != null) Color(0xFF2E7D32) else Color.Red
        )
        OutlinedTextField(batch, { batch = it }, label = { Text("Nomor batch") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        current?.let { Text("Stok batch saat ini: $it ${found?.unit ?: ""}") }
        OutlinedTextField(
            qty, { qty = it.filter(Char::isDigit) }, label = { Text("Jumlah") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                val c = code.trim().uppercase()
                val b = batch.trim().uppercase()
                val n = qty.toIntOrNull() ?: 0
                val item = dao.findItem(c)
                when {
                    item == null -> msg = "Kode barang tidak ditemukan. Daftarkan dulu di tab Barang."
                    b.isEmpty() -> msg = "Nomor batch wajib diisi"
                    n <= 0 -> msg = "Jumlah harus lebih dari 0"
                    type == "OUT" && dao.stockOf(c, b) < n ->
                        msg = "Stok batch tidak cukup (tersedia ${dao.stockOf(c, b)})"
                    else -> {
                        dao.insertTx(StockTx(itemCode = c, batchNo = b, type = type, qty = n, time = System.currentTimeMillis(), note = note.trim()))
                        msg = "Tersimpan: ${if (type == "IN") "masuk" else "keluar"} $n ${item.unit} (batch $b)"
                        qty = ""; note = ""
                        current = dao.stockOf(c, b)
                    }
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Simpan Transaksi") }
        if (msg.isNotEmpty()) Text(msg, Modifier.padding(top = 8.dp))
    }
}

@Composable
fun RiwayatScreen(dao: StockDao) {
    val history by remember { dao.history() }.collectAsState(emptyList())
    val itemList by remember { dao.items() }.collectAsState(emptyList())
    val fmt = remember { SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID")) }
    if (history.isEmpty()) {
        Text("Belum ada transaksi.", Modifier.padding(12.dp))
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(history, key = { it.id }) { t ->
            val item = itemList.find { it.code == t.itemCode }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (t.type == "IN") "MASUK" else "KELUAR",
                            color = if (t.type == "IN") Color(0xFF2E7D32) else Color(0xFFC62828),
                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                        )
                        Text(fmt.format(Date(t.time)), style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${t.itemCode} — ${item?.name ?: "-"}")
                    Text("Batch ${t.batchNo} • ${t.qty} ${item?.unit ?: ""}")
                    if (t.note.isNotEmpty()) Text("Catatan: ${t.note}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
